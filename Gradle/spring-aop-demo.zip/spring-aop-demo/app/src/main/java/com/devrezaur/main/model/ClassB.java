package com.devrezaur.main.model;

import org.springframework.stereotype.Component;

@Component
public class ClassB {

    public int anotherMethod(int num) {
        return num;
    }
}
