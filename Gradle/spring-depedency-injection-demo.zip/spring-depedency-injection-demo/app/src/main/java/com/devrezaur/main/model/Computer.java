package com.devrezaur.main.model;

public interface Computer {
    void printConfiguration();
}
